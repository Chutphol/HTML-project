// cart.js
document.addEventListener("DOMContentLoaded", () => {
    let cart = sessionStorage.getItem('cart') ? sessionStorage.getItem('cart').split(',') : [];
    let total = parseFloat(sessionStorage.getItem('total')) || 0;

    // Initial update of cart on page load
    updateCart();

    function calculateTotal() {
        total = cart.reduce((acc, item) => {
            const price = parseFloat(item.split(':')[1]);
            return acc + price;
        }, 0);
        sessionStorage.setItem('total', total.toFixed(2)); // Store the total as a string with 2 decimals
    }

    function updateCartCounter() {
        const counter = document.getElementById('cartcount');
        if (counter) {
            counter.textContent = `${cart.length}`;
        }
    }

    function addcart(productName, price) {
        cart.push(`${productName}:${price}`);
        sessionStorage.setItem('cart', cart.join(','));
        calculateTotal();
        updateCart();
        updateCartCounter();
    }

    function updateCart() {
        const cartItemsContainer = document.getElementById('cart-items');
        if (cartItemsContainer) {
            cartItemsContainer.innerHTML = '';

            cart.forEach(item => {
                const [name, price] = item.split(':');
                const li = document.createElement('li');
                li.textContent = `${name} - $${parseFloat(price).toFixed(2)}`;
                cartItemsContainer.appendChild(li);
            });
        }

        const totalPriceElement = document.getElementById('total-price');
        if (totalPriceElement) {
            totalPriceElement.textContent = `Total: $${total.toFixed(2)}`;
        }

        updateCartCounter();
    }

    function removeAll() {
        cart = [];
        total = 0;
        sessionStorage.removeItem('cart');
        sessionStorage.removeItem('total');
        updateCart();
    }    

    window.addcart = addcart;
    window.removeAll = removeAll;
});

// all-page.js
document.addEventListener("DOMContentLoaded", () => {
    let cart = sessionStorage.getItem('cart') ? sessionStorage.getItem('cart').split(',') : [];
    let total = parseFloat(sessionStorage.getItem('total')) || 0;

    function updateCartDisplay() {
        const cartItemsContainer = document.getElementById('cart-items');
        if (cartItemsContainer) {
            cartItemsContainer.innerHTML = '';

            cart.forEach(item => {
                const [name, price] = item.split(':');
                const li = document.createElement('li');
                li.textContent = `${name} - $${parseFloat(price).toFixed(2)}`;
                cartItemsContainer.appendChild(li);
            });
        }

        const totalPriceElement = document.getElementById('total-price');
        if (totalPriceElement) {
            totalPriceElement.textContent = `Total: $${total.toFixed(2)}`;
        }
    }

    updateCartDisplay();

    const completePurchaseButton = document.getElementById('complete-purchase');
    if (completePurchaseButton) {
        completePurchaseButton.addEventListener('click', function () {
            alert('Thank you for your purchase!');
            sessionStorage.removeItem('cart');
            sessionStorage.removeItem('total');
            sessionStorage.removeItem('cartcount');
            cart = [];
            total = 0;
            updateCartDisplay();
        });
    }
});
